// Get all the "Add to Cart" buttons
const addToCartButtons = document.querySelectorAll('.add-to-cart');

// Get the cart container element
const cartContainer = document.getElementById('cart-container');

// Initialize an empty cart array
let cart = [];

// Add event listeners to the "Add to Cart" buttons
addToCartButtons.forEach((button) => {
  button.addEventListener('click', () => {
    // Get the product information
    const product = {
      name: button.parentElement.querySelector('h3').textContent,
      price: parseFloat(button.parentElement.querySelector('span').textContent.slice(1)),
      quantity: 1
    };

    // Add the product to the cart
    addToCart(product);

    // Update the cart display
    updateCart();
  });
});

function addToCart(product) {
  // Check if the product is already in the cart
  const existingProduct = cart.find((item) => item.name === product.name);
  if (existingProduct) {
    existingProduct.quantity++;
  } else {
    cart.push(product);
  }
}

function updateCart() {
  // Clear the cart container
  cartContainer.innerHTML = '';

  // Display the items in the cart
  cart.forEach((product) => {
    const cartItem = document.createElement('div');
    cartItem.classList.add('cart-item');
    cartItem.innerHTML = `
      <span>${product.name}</span>
      <span>$${product.price.toFixed(2)}</span>
      <span>Qty: ${product.quantity}</span>
    `;
    cartContainer.appendChild(cartItem);
  });
}
